#include <iostream> 
#include<sstream>
#include<fstream>
#include<cstring>
using namespace std; 
  
 
string decrypt(string text, int s) 
{ 
    string result = ""; 
  
   
    for (int i=0;i<text.length();i++) 
    { 
         
        if (isupper(text[i])) 
            result += char(int(text[i]+s-65)%26 +65); 
  
 
    else
        result += char(int(text[i]+s-97)%26 +97); 
    } 
   
    return result; 
} 

int main()
{
	int b=1;
	int a=0; 
	string s1;
	string s2;
	int counter=0,shift;
	 string text="AfpzobqbJxqebjxqfzp_Pefcqzfmebopexsbybbkfkrpbcloqelrpxkaplcvbxop]jlpqcxjlrpivyvqebOljxkbjmbolop]fkmxoqfzrixo]yvGrifrpZxbpxo_Eltbsbo]qefpqfjbfkCxiiIaHP]fqfpqebqroklctxooflopcoljYxqzeIOqlefabqebjbppxdb]hbbmfkdfqpxcbcoljlqeboyxqzebpfkDFHFkpqfqrqb_"; 
    cout << "Text : " << text; 
    
    for(int i=0;i<26;i++)
    {
       	a=26-b;
    	b++;
    	cout<<decrypt(text,b)<<endl<<endl;
    	s1=decrypt(text,b);
    	counter++;

    	 if('D'==s1[0])
    	 {
    	 s2=s1;
    	 shift=counter;
    }
    	 
    	 
    	 
    	 
    	
	}
	
	
	
	cout<<endl<<endl;
	
	cout<<"The shift is: "<<25-shift<<endl;
	
	cout<<"The decryption is: "<<s2;
	
	ofstream o1;
	o1.open("Encrypted text.txt",ios::app);
	
	if(!o1)
	cout<<"No file exists: \n";
	
	else
	{
		o1<<s2;
	}
	
	
    
    
	  
}

