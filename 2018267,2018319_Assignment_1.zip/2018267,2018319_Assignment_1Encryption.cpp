#include <iostream> 
#include<fstream>
#include<sstream>
#include<cstring>
using namespace std; 
  

string encrypt(string text, int s) 
{ 
    string result = ""; 
  
  
    for (int i=0;i<text.length();i++) 
    { 
 
        if (isupper(text[i])) 
            result += char(int(text[i]+s-65)%26 +65); 
  
  
    else
        result += char(int(text[i]+s-97)%26 +97); 
    } 
  
  
    return result; 
} 
  

int main() 
{ 
    
   	string s[100];
	ifstream i1;
	string text;
	int j=0;
	i1.open("Assignment 1_Plaintext.txt",ios::in);
	
	if(!i1)
	cout<<"No file exist: ";
	
	else
	{
	
		for(int i=0;i<55;i++)
		{
			i1>>s[i];
		}
		
	}
		
	for(int i=0;i<55;i++)
		{
		
			text=text+s[i];
		}
		
		
		
    int shift = 23; 
    cout << "Text : " << text; 
    cout << "\nShift: " << shift; 
    cout << "\nCipher: " << encrypt(text, shift); 
    return 0; 
}

